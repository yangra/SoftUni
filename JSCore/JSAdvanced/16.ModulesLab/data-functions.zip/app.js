//let Person = require('./person');
//let mapSort = require('./sort-map');
let functions = require('./data-functions');

let sort = functions.sort;
let filter = functions.filter;

result.sort = sort;
result.filter = filter;
