//let Person = require('./person');
//let mapSort = require('./sort-map');
//let functions = require('./data-functions');

let Entity = require('./entity');
let Dog = require('./dog');
let Person = require('./new-person');
let Student = require('./student');

result.Entity = Entity;
result.Dog = Dog;
result.Person = Person;
result.Student = Student;