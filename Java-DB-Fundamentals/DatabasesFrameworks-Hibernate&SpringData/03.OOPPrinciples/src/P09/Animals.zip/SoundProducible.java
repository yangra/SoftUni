package P09;

public interface SoundProducible {
    public void produceSound();
}
