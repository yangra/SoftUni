package P04;

public interface Callable {
    void call( String number);
}
