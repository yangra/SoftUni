package P04;

public interface Browsable {
    void browse(String site);
}
