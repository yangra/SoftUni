package P06;

public interface Identifiable {
    String getId();
}
