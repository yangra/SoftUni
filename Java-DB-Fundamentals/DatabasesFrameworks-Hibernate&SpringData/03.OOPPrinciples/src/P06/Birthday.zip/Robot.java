package P06;

public interface Robot {
    String getModel();
}
