package P06;


public interface Human {
    String getName();
    int getAge();
}
