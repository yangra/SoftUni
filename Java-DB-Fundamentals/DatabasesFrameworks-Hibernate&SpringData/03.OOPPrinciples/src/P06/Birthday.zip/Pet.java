package P06;

/**
 * Created by Yana on 7/5/2017.
 */
public interface Pet {
    String getName();
}
