package P03;


public interface Driver {
    String getName();
}
