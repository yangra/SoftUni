package P03;

public interface Car {
    void brakes();
    void gas();
    String getModel();
}
