package P08;

public abstract class Vehicle {
    protected double fuelQuantity;
    protected double fuelConsumption;

    public Vehicle(double fuelQuantity, double fuelConsumption) {
        this.setFuelQuantity(fuelQuantity);
        this.setFuelConsumption(fuelConsumption);
    }

    protected double getFuelQuantity() {
        return fuelQuantity;
    }

    protected void setFuelQuantity(double fuelQuantity) {
        this.fuelQuantity = fuelQuantity;
    }

    protected double getFuelConsumption() {
        return fuelConsumption;
    }

    protected void setFuelConsumption(double fuelConsumption) {
        this.fuelConsumption = fuelConsumption;
    }

    protected void refuel(double litres){
        this.fuelQuantity += litres;
    }

    protected boolean canTravel(double distance){
        if(this.getFuelConsumption()*distance<fuelQuantity){
            return true;
        }
        return false;
    }

    protected void takeFuel(double distance){
        fuelQuantity -= distance*fuelConsumption;
    }
}
