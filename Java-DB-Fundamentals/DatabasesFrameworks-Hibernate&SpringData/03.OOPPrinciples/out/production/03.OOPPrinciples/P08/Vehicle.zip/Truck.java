package P08;


import java.text.DecimalFormat;

public class Truck extends Vehicle {

    Truck(double quantity, double consumption){
        super(quantity,consumption);
    }

    @Override
    protected void setFuelConsumption(double fuelConsumption) {
        super.setFuelConsumption(fuelConsumption+1.6);
    }

    @Override
    protected void refuel(double litres) {
        super.refuel(litres*0.95);
    }

    public void drive(double distance){
        if(this.canTravel(distance)){
            DecimalFormat df = new DecimalFormat("###0.######");
            System.out.println("Truck travelled " + df.format(distance) + " km");
            super.takeFuel(distance);
        }else{
            System.out.println("Truck needs refueling");
        }
    }
}
