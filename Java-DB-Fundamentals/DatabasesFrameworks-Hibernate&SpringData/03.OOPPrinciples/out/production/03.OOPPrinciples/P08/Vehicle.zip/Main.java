package P08;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        String[] carInfo = scan.nextLine().split("\\s");
        String[] truckInfo = scan.nextLine().split("\\s");
        Car car = new Car(Double.parseDouble(carInfo[1]), Double.parseDouble(carInfo[2]));
        Truck truck = new Truck(Double.parseDouble(truckInfo[1]),Double.parseDouble(truckInfo[2]));
        int moves = Integer.parseInt(scan.nextLine());
        for (int i = 0; i < moves ; i++) {
            String[] command = scan.nextLine().split("\\s");
            if ("Car".equals(command[1])){
                if("Drive".equals(command[0])){
                    car.drive(Double.parseDouble(command[2]));
                }else{
                    car.refuel(Double.parseDouble(command[2]));
                }
            }else{
                if("Drive".equals(command[0])){
                    truck.drive(Double.parseDouble(command[2]));
                }else {
                    truck.refuel(Double.parseDouble(command[2]));
                }
            }
        }
        System.out.printf("Car: %.2f\n",car.getFuelQuantity());
        System.out.printf("Truck: %.2f\n", truck.getFuelQuantity());
    }
}
