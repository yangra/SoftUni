package P08;

import java.text.DecimalFormat;

public class Car extends Vehicle {
    Car(double quantity, double consumption){
        super(quantity,consumption);
    }

    @Override
    protected void setFuelConsumption(double fuelConsumption) {
        super.setFuelConsumption(fuelConsumption+0.9);
    }

    public void drive(double distance){

        if(this.canTravel(distance)){
            DecimalFormat df = new DecimalFormat("###0.######");
            System.out.println("Car travelled " + df.format(distance) + " km");
            super.takeFuel(distance);
        }else{
            System.out.println("Car needs refueling");
        }
    }
}
