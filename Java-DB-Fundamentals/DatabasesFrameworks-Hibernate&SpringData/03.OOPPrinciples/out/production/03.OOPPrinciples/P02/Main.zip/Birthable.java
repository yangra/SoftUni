package P02;

public interface Birthable {
    String getBirthDate();
}

