package P02;

public interface Identifiable {
    String getId();
}
