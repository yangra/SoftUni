package P05;

public interface Identifiable {
    String getId();
}
