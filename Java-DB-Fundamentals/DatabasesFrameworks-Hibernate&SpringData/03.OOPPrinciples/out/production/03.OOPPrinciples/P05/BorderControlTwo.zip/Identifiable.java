package P05;

 interface Identifiable {
    String getId();
}
