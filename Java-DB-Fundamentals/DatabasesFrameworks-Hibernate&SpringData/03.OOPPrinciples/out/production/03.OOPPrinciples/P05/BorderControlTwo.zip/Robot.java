package P05;


public interface Robot {
    String getModel();
}
