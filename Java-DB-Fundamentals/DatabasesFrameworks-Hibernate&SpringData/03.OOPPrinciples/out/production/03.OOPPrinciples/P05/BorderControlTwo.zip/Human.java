package P05;

/**
 * Created by Yana on 7/5/2017.
 */
public interface Human {
    String getName();
    int getAge();
}
