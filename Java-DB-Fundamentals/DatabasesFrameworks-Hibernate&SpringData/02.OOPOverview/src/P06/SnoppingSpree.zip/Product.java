package P06;

import java.math.BigDecimal;

class Product {


    private String name;
    private BigDecimal cost;

    Product(String name, BigDecimal cost) throws IllegalStateException{
        this.setName(name);
        this.setCost(cost);
    }

    private void setName(String name) throws  IllegalStateException{
        if(name.isEmpty()||name.trim().equals("")){
            System.out.println("Name cannot be empty");
            throw new IllegalStateException("Name cannot be empty");
        }
        this.name = name;
    }

    private void setCost(BigDecimal cost) throws IllegalStateException {
        if (cost.compareTo(BigDecimal.ZERO)==-1){
            System.out.println("Money cannot be negative");
            throw new IllegalStateException("Money cannot be negative");
        }
        this.cost = cost;
    }

    BigDecimal getCost() {
        return cost;
    }

    String getName() {
        return name;
    }
}
