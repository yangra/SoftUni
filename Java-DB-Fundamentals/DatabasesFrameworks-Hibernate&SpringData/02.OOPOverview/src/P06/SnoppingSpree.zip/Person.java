package P06;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

class Person {
    private String name;
    private BigDecimal money;
    private List<Product> bag;

    Person (String name, BigDecimal money) throws IllegalStateException{
        this.setName(name);
        this.setMoney(money);
        this.bag = new ArrayList<>();
    }

    private void setName(String name) throws IllegalStateException {
        if(name.isEmpty()||name.trim().equals("")){
            System.out.println("Name cannot be empty");
            throw new IllegalStateException("Name cannot be empty");
        }
        this.name = name;
    }

    private void setMoney(BigDecimal money) throws IllegalStateException {
        if(money.compareTo(BigDecimal.ZERO)==-1){
            System.out.println("Money cannot be negative");
            throw new IllegalStateException("Money cannot be negative");
        }
        this.money = money;
    }

    String getName() {
        return name;
    }

    public BigDecimal getMoney() {
        return money;
    }

    List<Product> getBag() {
        return bag;
    }

    void addToBag(Product product){
        if (this.money.compareTo(product.getCost()) >= 0) {
            this.bag.add(product);
            this.money = this.money.subtract(product.getCost());
            System.out.printf("%s bought %s\n", this.getName(), product.getName());
        } else {
            System.out.printf("%s can't afford %s\n", this.getName(), product.getName());
        }

    }
}
