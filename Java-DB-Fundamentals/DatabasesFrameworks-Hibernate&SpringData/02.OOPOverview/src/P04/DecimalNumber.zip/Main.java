package P04;

import java.util.Scanner;


public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        DecimalNumber dn = new DecimalNumber(scan.nextDouble());
        dn.reverse();
    }
}
