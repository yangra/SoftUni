package P11.exceptions;


public class InvalidSongNameExcepton extends InvalidSongException {
    public InvalidSongNameExcepton(String message) {
        super(message);
    }
}
