package P11.exceptions;


public class InvalidSongException extends Exception {
    public InvalidSongException(String message) {
        super(message);
    }
}
