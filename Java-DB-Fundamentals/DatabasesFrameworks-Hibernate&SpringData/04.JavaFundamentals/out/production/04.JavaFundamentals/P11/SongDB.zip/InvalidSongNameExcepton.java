package P11;


public class InvalidSongNameExcepton extends InvalidSongException {
    public InvalidSongNameExcepton(String message) {
        super(message);
    }
}
