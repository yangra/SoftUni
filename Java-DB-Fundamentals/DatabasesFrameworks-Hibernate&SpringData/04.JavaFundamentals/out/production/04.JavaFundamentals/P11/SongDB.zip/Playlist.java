package P11;


import java.util.ArrayList;
import java.util.List;

public class Playlist {
    private List<Song> songs;

    public Playlist() {
        this.songs = new ArrayList<>();
    }

    public List<Song> getSongs() {
        return songs;
    }

    void addSong(Song song) {
        this.songs.add(song);
        System.out.println("Song added.");
    }

    String length() {
        Integer length = 0;
        for (int i = 0; i < songs.size(); i++) {
            length += songs.get(i).getSongLengthInSec();
        }
        Integer hours = length / 60 / 60;
        Integer minutes = (length - 60 * 60 * hours) / 60;
        Integer seconds = length % 60;

        return hours.toString() + "h " + minutes.toString() + "m " + seconds.toString() + "s";
    }


}
