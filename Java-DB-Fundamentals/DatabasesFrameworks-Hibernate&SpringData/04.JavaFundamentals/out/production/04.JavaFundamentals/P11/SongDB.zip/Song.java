package P11;


public class Song {
    private String artistName;
    private String songName;
    private int songLengthInSec;
    private int minutes;
    private int seconds;


    public Song(String artistName, String songName, int minutes, int seconds) {
        this.setArtistName(artistName);
        this.setSongName(songName);
        this.setSongLengthInSec(minutes * 60 + seconds);
        this.setMinutes(minutes);
        this.setSeconds(seconds);

    }

    public String getArtistName() {
        return artistName;
    }

    private void setArtistName(String artistName) {
        if (artistName == null || artistName.length() >= 3 && artistName.length() <= 20) {
            this.artistName = artistName;
        } else {
            throw new InvalidArtistNameException("Artist name should be between 3 and 20 symbols.");
        }

    }

    public String getSongName() {
        return songName;
    }

    private void setSongName(String songName) {
        if (songName == null || songName.length() < 3 || songName.length() > 30) {
            throw new InvalidSongNameExcepton("Song name should be between 3 and 30 symbols.");
        }
        this.songName = songName;
    }

    public int getSongLengthInSec() {
        return songLengthInSec;
    }

    private void setSongLengthInSec(int songLengthInSec) {
        if (songLengthInSec < 0 || songLengthInSec > 899) {
            throw new InvalidSongLengthException("Invalid song length");
        }
        this.songLengthInSec = songLengthInSec;
    }

    public int getMinutes() {
        return minutes;
    }

    private void setMinutes(int minutes) {
        if (minutes < 0 || minutes > 14) {
            throw new InvalidSongMinutesException("Song minutes should be between 0 and 14.");
        }
        this.minutes = minutes;
    }

    public int getSeconds() {
        return seconds;
    }

    private void setSeconds(int seconds) {
        if (seconds < 0 || seconds > 59) {
            throw new InvalidSongSecondsException("Song seconds should be between 0 and 59.");
        }
        this.seconds = seconds;
    }
}
