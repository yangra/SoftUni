package P11;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        try {
            int numberOfSongs = Integer.parseInt(reader.readLine());
            Playlist songs = new Playlist();
            for (int i = 0; i < numberOfSongs ; i++) {
                String[] songData = reader.readLine().split(";");
                if(songData.length==3){
                    String artistName = songData[0];
                    String songName = songData[1];
                    int minutes = 0;
                    int seconds = 0;
                    try{
                        String[] length = songData[2].split(":");
                        if(length.length==2){
                            minutes = Integer.parseInt(length[0]);
                            seconds = Integer.parseInt(length[1]);
                        }else{
                            System.out.println("Invalid song.");
                        }
                        try {
                            Song song = new Song(artistName, songName, minutes, seconds);
                            songs.addSong(song);
                        }catch (InvalidSongException ise){
                            System.out.println(ise.getMessage());
                        }
                    } catch (NumberFormatException nfe){
                        System.out.println("Please specify valid song length.");
                    }
                }else{
                    System.out.println("Invalid song.");
                }
            }
            System.out.println("Songs added: "+ songs.getSongs().size());
            System.out.println("Playlist length: " + songs.length());
        }catch (NumberFormatException nfe){
            System.out.println("Please specify number of songs first!");
        }


    }
}
