package _02Blobs.interfaces;

public interface Executable {

    String execute();
}
