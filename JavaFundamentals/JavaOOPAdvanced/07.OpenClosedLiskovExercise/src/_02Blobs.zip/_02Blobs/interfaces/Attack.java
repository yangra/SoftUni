package _02Blobs.interfaces;



public interface Attack {
    void execute(Blob attacker, Blob target);
}
