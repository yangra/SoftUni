package _02Blobs.interfaces;

public interface OutputWriter {

   void writeLine(String output,Object... params);

   void writeLine(String output);
}
