package _02Blobs.interfaces;

public interface InputReader {

    String readLine();
}
