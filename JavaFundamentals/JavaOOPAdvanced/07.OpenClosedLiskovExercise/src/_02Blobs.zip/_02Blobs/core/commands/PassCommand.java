package _02Blobs.core.commands;

import _02Blobs.core.BaseCommand;

public class PassCommand extends BaseCommand {
    @Override
    public String execute() {
        return null;
    }
}
