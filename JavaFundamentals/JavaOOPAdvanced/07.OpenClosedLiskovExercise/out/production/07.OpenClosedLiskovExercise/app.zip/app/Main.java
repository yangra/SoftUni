package app;

import app.controllers.AppenderController;
import app.engine.Engine;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Main {
    public static void main(String[] args) {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        AppenderController controller = new AppenderController(reader);

        Engine engine = new Engine(reader, controller);
        engine.run();
    }
}
