package app.repositories;

import app.models.interfaces.Appender;


public class AppenderRepositoryImpl implements AppenderRepository {
    private Appender[] appenders;

    public AppenderRepositoryImpl(int size) {
        this.appenders = new Appender[size];
    }

    @Override
    public void add(Appender appender, int index) {
        this.appenders[index] = appender;
    }

    @Override
    public Appender[] findAll() {
        return this.appenders;
    }
}
