package app.models.interfaces;

import java.io.IOException;
import java.math.BigInteger;
import java.util.List;

public interface File {

    BigInteger getSize();

    void write(String log);
}
