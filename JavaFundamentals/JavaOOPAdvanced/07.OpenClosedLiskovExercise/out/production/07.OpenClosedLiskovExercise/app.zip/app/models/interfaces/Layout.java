package app.models.interfaces;

public interface Layout {
    String format(String dateTime, String error, String type);
}
