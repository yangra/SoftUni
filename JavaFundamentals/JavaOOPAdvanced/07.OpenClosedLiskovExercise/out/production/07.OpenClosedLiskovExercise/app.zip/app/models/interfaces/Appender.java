package app.models.interfaces;

import app.models.enums.ReportLevel;

public interface Appender {
    void append(String dateTime, String error, String type);
    void setReportLevel(ReportLevel reportLevel);
}
