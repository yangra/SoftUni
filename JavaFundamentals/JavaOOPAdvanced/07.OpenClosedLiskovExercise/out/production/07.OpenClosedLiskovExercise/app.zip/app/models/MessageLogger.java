package app.models;

import app.models.interfaces.Appender;
import app.models.interfaces.Logger;

public class MessageLogger implements Logger {


    private Appender[] appenders;

    public MessageLogger(Appender... appenders) {
        this.appenders = new Appender[appenders.length];
        for (int i = 0; i < appenders.length ; i++) {
            this.appenders[i] = appenders[i];
        }
    }

    @Override
    public void logError(String date, String error) {
        for (int i = 0; i < this.appenders.length ; i++) {
            this.appenders[i].append(date, error, "ERROR");
        }
    }

    @Override
    public void logWarning(String date, String warning) {
        for (int i = 0; i < this.appenders.length ; i++) {
            this.appenders[i].append(date, warning, "WARNING");
        }
    }

    @Override
    public void logInfo(String date, String info) {
        for (int i = 0; i < this.appenders.length ; i++) {
            this.appenders[i].append(date, info, "INFO");
        }
    }

    @Override
    public void logCritical(String date, String critical) {
        for (int i = 0; i < this.appenders.length ; i++) {
            this.appenders[i].append(date, critical, "CRITICAL");
        }
    }

    @Override
    public void logFatal(String date, String fatal) {
        for (int i = 0; i < this.appenders.length ; i++) {
            this.appenders[i].append(date, fatal, "FATAL");
        }
    }
}
