package app.factories;

import app.models.ConsoleAppender;
import app.models.FileAppender;
import app.models.LogFile;
import app.models.interfaces.Appender;
import app.models.interfaces.File;
import app.models.interfaces.Layout;

public final class AppenderFactory {
    public AppenderFactory() {
    }

    public static Appender createFileAppender(Layout layout){
        FileAppender appender = new FileAppender(layout);
        File file = new LogFile();
        appender.setFile(file);
        return appender;
    }

    public static Appender createConsoleAppender(Layout layout){
        return new ConsoleAppender(layout);
    }
}
