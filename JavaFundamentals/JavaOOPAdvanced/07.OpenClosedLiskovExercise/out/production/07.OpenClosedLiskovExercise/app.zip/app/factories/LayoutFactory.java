package app.factories;

import app.models.SimpleLayout;
import app.models.XmlLayout;
import app.models.interfaces.Layout;

public final class LayoutFactory {
    private LayoutFactory() {
    }

    public static Layout createXmlLayout(){
        return new XmlLayout();
    }

    public static Layout createSimpleLayout(){
        return new SimpleLayout();
    }
}
