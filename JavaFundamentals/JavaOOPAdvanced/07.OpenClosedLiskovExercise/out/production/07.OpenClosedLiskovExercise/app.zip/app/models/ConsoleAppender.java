package app.models;

import app.models.enums.ReportLevel;
import app.models.interfaces.Appender;
import app.models.interfaces.Layout;

import java.math.BigInteger;

public class ConsoleAppender extends AppenderImpl implements Appender {


    public ConsoleAppender(Layout layout) {
        super(layout);
    }

    @Override
    public void append(String dateTime, String error, String type) {
        if (this.getReportLevel().ordinal() <= ReportLevel.valueOf(type).ordinal()) {
            String log = super.getLayout().format(dateTime, error, type);
            System.out.println(log);
            super.setAppendedMessages(super.getAppendedMessages().add(BigInteger.ONE));
        }
    }


}
