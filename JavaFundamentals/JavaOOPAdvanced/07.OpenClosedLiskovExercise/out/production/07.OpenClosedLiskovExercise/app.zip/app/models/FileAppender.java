package app.models;

import app.models.enums.ReportLevel;
import app.models.interfaces.Appender;
import app.models.interfaces.File;
import app.models.interfaces.Layout;


import java.math.BigInteger;

public class FileAppender extends AppenderImpl implements Appender {

    private File logFile;

    public FileAppender(Layout layout) {
        super(layout);
    }

    public void setFile(File file) {
        this.logFile = file;
    }

    @Override
    public void append(String dateTime, String error, String type) {
        if (this.getReportLevel().ordinal() <= ReportLevel.valueOf(type).ordinal()) {
            //List<String> log = Arrays.asList(super.getLayout().format(dateTime, error, type).split("\\n"));
            String log = super.getLayout().format(dateTime, error, type);
            this.logFile.write(log);
            super.setAppendedMessages(super.getAppendedMessages().add(BigInteger.ONE));
        }
    }

    @Override
    public String toString() {
        return super.toString() + ", File size: " + this.logFile.getSize();
    }

}
