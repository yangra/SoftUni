package app.repositories;

import app.models.interfaces.Appender;

import java.util.List;

public interface AppenderRepository {

    void add(Appender appender, int index);

    Appender[] findAll();
}
