package _01Logger.models.interfaces;

public interface Layout {

    String format(String dateTime, String error, String type);
}
