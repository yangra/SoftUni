package _01Logger.models.enums;

public enum ReportLevel {
    INFO, WARNING, ERROR, CRITICAL, FATAL;
}
