package BoatSimulator.exceptions;

public class NonExistingModelException extends Exception {
    public NonExistingModelException(String message) {
        super(message);
    }
}
