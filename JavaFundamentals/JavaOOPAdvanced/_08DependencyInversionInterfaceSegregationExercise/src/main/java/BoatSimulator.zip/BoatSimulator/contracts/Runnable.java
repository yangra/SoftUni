package BoatSimulator.contracts;

public interface Runnable {

    void run();
}
