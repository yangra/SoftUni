package BoatSimulator.enumeration;

public enum EngineType
{
    JET,
    STERNDRIVE;
}
