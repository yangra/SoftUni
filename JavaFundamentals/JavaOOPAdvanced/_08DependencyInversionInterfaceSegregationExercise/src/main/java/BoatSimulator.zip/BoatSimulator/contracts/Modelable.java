package BoatSimulator.contracts;

public interface Modelable {
    String getModel();
}
