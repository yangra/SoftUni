package BoatSimulator.models.boat_engines;

import BoatSimulator.contracts.Modelable;

public interface BoatEngine extends Modelable {

    int getOutput();
}
