package app.waste_disposal;

import org.junit.Test;

import static org.junit.Assert.*;

public class DefaultGarbageProcessorTest {
    @Test
    public void getStrategyHolder() throws Exception {
    }

    @Test
    public void processWaste() throws Exception {
    }

}