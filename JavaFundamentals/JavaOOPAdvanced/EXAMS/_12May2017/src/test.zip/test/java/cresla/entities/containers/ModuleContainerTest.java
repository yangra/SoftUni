package cresla.entities.containers;

import cresla.interfaces.AbsorbingModule;
import cresla.interfaces.Container;
import cresla.interfaces.EnergyModule;
import org.junit.Assert;
import org.junit.Test;
import org.mockito.Mockito;

public class ModuleContainerTest {

    public static final int EXPECTED_ENERGY_OUTPUT = 200;
    public static final int EXPECTED_TOTAL_HEAT_ABSORBTION = 300;
    public static final int EXPECTED_HEAT_ABSORBTION = 200;
    public static final int EXPECTED_TOTAL_ENERGY_OUTPUT = 300;

    @Test(expected = IllegalArgumentException.class)
    public void addNullEnergyModule() throws Exception {
        EnergyModule energyModule = null;
        Container container = new ModuleContainer(16);
        container.addEnergyModule(energyModule);
    }

    @Test
    public void addEnergyModuleToFullContainer() throws Exception {
        EnergyModule energyModule1 = Mockito.mock(EnergyModule.class);
        EnergyModule energyModule2 = Mockito.mock(EnergyModule.class);
        Mockito.when(energyModule1.getEnergyOutput()).thenReturn(100);
        Mockito.when(energyModule2.getEnergyOutput()).thenReturn(200);

        Container container = new ModuleContainer(1);
        container.addEnergyModule(energyModule1);
        container.addEnergyModule(energyModule2);

        Assert.assertEquals("Does not add properly when container full", EXPECTED_ENERGY_OUTPUT, container.getTotalEnergyOutput());
    }

    @Test
    public void addEnergyModuleToContainer() throws Exception {
        EnergyModule energyModule1 = Mockito.mock(EnergyModule.class);
        EnergyModule energyModule2 = Mockito.mock(EnergyModule.class);
        Mockito.when(energyModule1.getId()).thenReturn(1);
        Mockito.when(energyModule1.getEnergyOutput()).thenReturn(100);
        Mockito.when(energyModule2.getId()).thenReturn(2);
        Mockito.when(energyModule2.getEnergyOutput()).thenReturn(200);

        Container container = new ModuleContainer(16);
        container.addEnergyModule(energyModule1);
        container.addEnergyModule(energyModule2);

        Assert.assertEquals("Does not add module properly", EXPECTED_TOTAL_ENERGY_OUTPUT, container.getTotalEnergyOutput());
    }

    @Test(expected = IllegalArgumentException.class)
    public void addNullAbsorbingModule() throws Exception {
        AbsorbingModule absorbingModule = null;
        Container container = new ModuleContainer(16);
        container.addAbsorbingModule(absorbingModule);
    }

    @Test
    public void addAbsorbingModuleToFullContainer() throws Exception {
        AbsorbingModule absorbingModule1 = Mockito.mock(AbsorbingModule.class);
        AbsorbingModule absorbingModule2 = Mockito.mock(AbsorbingModule.class);
        Mockito.when(absorbingModule1.getHeatAbsorbing()).thenReturn(100);
        Mockito.when(absorbingModule2.getHeatAbsorbing()).thenReturn(200);

        Container container = new ModuleContainer(1);
        container.addAbsorbingModule(absorbingModule1);
        container.addAbsorbingModule(absorbingModule2);

        Assert.assertEquals("Does not add absorbing module properly on full collection",
                EXPECTED_HEAT_ABSORBTION, container.getTotalHeatAbsorbing());

    }

    @Test
    public void addAbsorbingModule() throws Exception {
        AbsorbingModule absorbingModule1 = Mockito.mock(AbsorbingModule.class);
        AbsorbingModule absorbingModule2 = Mockito.mock(AbsorbingModule.class);
        Mockito.when(absorbingModule1.getHeatAbsorbing()).thenReturn(100);
        Mockito.when(absorbingModule1.getId()).thenReturn(1);
        Mockito.when(absorbingModule2.getHeatAbsorbing()).thenReturn(200);
        Mockito.when(absorbingModule2.getId()).thenReturn(2);

        Container container = new ModuleContainer(16);
        container.addAbsorbingModule(absorbingModule1);
        container.addAbsorbingModule(absorbingModule2);

        Assert.assertEquals("Does not add absorbing module properly",
                EXPECTED_TOTAL_HEAT_ABSORBTION, container.getTotalHeatAbsorbing());

    }

    @Test
    public void getTotalEnergyOutput() throws Exception {
        EnergyModule energyModule1 = Mockito.mock(EnergyModule.class);
        EnergyModule energyModule2 = Mockito.mock(EnergyModule.class);
        Mockito.when(energyModule1.getId()).thenReturn(1);
        Mockito.when(energyModule1.getEnergyOutput()).thenReturn(100);
        Mockito.when(energyModule2.getId()).thenReturn(2);
        Mockito.when(energyModule2.getEnergyOutput()).thenReturn(200);

        Container container = new ModuleContainer(16);
        container.addEnergyModule(energyModule1);
        container.addEnergyModule(energyModule2);

        Assert.assertEquals("Does not add energy output properly", EXPECTED_TOTAL_HEAT_ABSORBTION, container.getTotalEnergyOutput());
    }

    @Test
    public void getTotalHeatAbsorbing() throws Exception {
        AbsorbingModule absorbingModule1 = Mockito.mock(AbsorbingModule.class);
        AbsorbingModule absorbingModule2 = Mockito.mock(AbsorbingModule.class);
        Mockito.when(absorbingModule1.getHeatAbsorbing()).thenReturn(100);
        Mockito.when(absorbingModule1.getId()).thenReturn(1);
        Mockito.when(absorbingModule2.getHeatAbsorbing()).thenReturn(200);
        Mockito.when(absorbingModule2.getId()).thenReturn(2);

        Container container = new ModuleContainer(16);
        container.addAbsorbingModule(absorbingModule1);
        container.addAbsorbingModule(absorbingModule2);

        Assert.assertEquals("Does not add absorbing heat properly",
                EXPECTED_TOTAL_HEAT_ABSORBTION, container.getTotalHeatAbsorbing());
    }

    @Test
    public void removeOldestModuleTest() throws Exception {
        AbsorbingModule absorbingModule1 = Mockito.mock(AbsorbingModule.class);
        AbsorbingModule absorbingModule2 = Mockito.mock(AbsorbingModule.class);
        Mockito.when(absorbingModule1.getHeatAbsorbing()).thenReturn(100);
        Mockito.when(absorbingModule2.getHeatAbsorbing()).thenReturn(200);

        Container container = new ModuleContainer(1);
        container.addAbsorbingModule(absorbingModule1);
        container.addAbsorbingModule(absorbingModule2);

        Assert.assertEquals("Does not add absorbing module properly on full collection",
                EXPECTED_HEAT_ABSORBTION, container.getTotalHeatAbsorbing());
    }

}