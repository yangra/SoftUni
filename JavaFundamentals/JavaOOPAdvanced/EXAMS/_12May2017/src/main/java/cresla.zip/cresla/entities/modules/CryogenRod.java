package cresla.entities.modules;

public class CryogenRod extends EnergyModuleImpl {

    public CryogenRod(int id, int energyOutput) {
        super(id, energyOutput);
    }
}
