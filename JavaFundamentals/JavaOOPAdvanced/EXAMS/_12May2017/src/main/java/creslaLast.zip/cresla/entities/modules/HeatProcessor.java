package cresla.entities.modules;


public class HeatProcessor extends AbsorbingModuleImpl {

    public HeatProcessor(int id, int heatAbsorbing) {
        super(id, heatAbsorbing);
    }

    @Override
    public String toString() {
        return String.format("%s Module - %d\n%s: %d",
                this.getClass().getSimpleName(), super.getId(), "heatAbsorbing", super.getHeatAbsorbing());
    }
}
