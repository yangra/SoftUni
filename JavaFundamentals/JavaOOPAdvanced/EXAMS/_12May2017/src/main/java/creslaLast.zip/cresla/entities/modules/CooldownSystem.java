package cresla.entities.modules;

public class CooldownSystem extends AbsorbingModuleImpl {


    public CooldownSystem(int id, int heatAbsorbing) {
        super(id, heatAbsorbing);
    }

    @Override
    public String toString() {
        return String.format("%s Module - %d\n%s: %d",
                this.getClass().getSimpleName(), super.getId(), "heatAbsorbing", super.getHeatAbsorbing());
    }
}
