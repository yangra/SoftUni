package emergency.enums;

public enum EmergencyLevel {
    Minor,
    Major,
    Disaster
}
