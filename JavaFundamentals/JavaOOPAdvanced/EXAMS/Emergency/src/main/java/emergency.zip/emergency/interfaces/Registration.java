package emergency.interfaces;

public interface Registration {
}
