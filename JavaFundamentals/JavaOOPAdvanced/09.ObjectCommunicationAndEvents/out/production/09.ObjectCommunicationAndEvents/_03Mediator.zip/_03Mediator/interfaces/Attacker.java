package _03Mediator.interfaces;

public interface Attacker {
    void attack();
    void setTarget(Target target);
}
