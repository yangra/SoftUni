package _03Mediator.enums;

public enum LogType {
    ATTACK, MAGIC, TARGET, ERROR, EVENT;
}
