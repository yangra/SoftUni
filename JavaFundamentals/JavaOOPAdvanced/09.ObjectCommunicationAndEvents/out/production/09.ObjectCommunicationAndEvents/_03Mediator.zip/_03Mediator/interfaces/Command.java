package _03Mediator.interfaces;

public interface Command {

    void execute();
}
