package _03Mediator.interfaces;

public interface Executor {

    void executeCommand(Command command);
}
