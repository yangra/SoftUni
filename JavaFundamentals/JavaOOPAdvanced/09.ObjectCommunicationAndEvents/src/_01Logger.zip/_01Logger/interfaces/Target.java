package _01Logger.interfaces;

public interface Target {
    void receiveDamage(int dmg);
    boolean isDead();
}