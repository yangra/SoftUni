package _01Logger.interfaces;

public interface Attacker {
    void attack();
    void setTarget(Target target);
}
