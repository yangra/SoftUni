package _01Logger.enums;

public enum LogType {
    ATTACK, MAGIC, TARGET, ERROR, EVENT;
}
