package _04Observer.interfaces;

public interface Command {

    void execute();
}
