package _04Observer.interfaces;

public interface Attacker {
    void attack();
    void setTarget(Target target);
}
