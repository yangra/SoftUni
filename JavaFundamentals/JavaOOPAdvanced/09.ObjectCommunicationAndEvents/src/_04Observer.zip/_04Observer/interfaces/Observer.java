package _04Observer.interfaces;

public interface Observer {

    void update(int reward);
}
