package _04Observer.enums;

public enum LogType {
    ATTACK, MAGIC, TARGET, ERROR, EVENT;
}
