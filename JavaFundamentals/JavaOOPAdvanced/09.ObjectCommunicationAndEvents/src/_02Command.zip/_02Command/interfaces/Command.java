package _02Command.interfaces;

public interface Command {

    void execute();
}
