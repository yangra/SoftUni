package _02Command.interfaces;

public interface Executor {

    void executeCommand(Command command);
}
