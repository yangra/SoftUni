package _02Command.interfaces;

public interface Attacker {
    void attack();
    void setTarget(Target target);
}
