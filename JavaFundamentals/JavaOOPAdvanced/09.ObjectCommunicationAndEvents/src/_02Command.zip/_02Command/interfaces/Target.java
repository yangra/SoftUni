package _02Command.interfaces;

public interface Target {
    void receiveDamage(int dmg);
    boolean isDead();
}