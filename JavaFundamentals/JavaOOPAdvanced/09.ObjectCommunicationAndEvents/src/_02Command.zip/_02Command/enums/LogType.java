package _02Command.enums;

public enum LogType {
    ATTACK, MAGIC, TARGET, ERROR, EVENT;
}
