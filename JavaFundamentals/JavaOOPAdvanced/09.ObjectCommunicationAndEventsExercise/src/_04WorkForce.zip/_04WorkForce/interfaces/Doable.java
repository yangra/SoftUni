package _04WorkForce.interfaces;

public interface Doable {

    String getName();
    int getWorkHoursRequired();
}
