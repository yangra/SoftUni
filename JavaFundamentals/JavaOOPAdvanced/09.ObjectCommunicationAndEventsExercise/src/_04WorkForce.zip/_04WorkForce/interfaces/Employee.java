package _04WorkForce.interfaces;

public interface Employee {

    int getWorkHoursPerWeek();
}
