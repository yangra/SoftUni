package _04WorkForce.interfaces;

public interface Observable {
    void update();
}
