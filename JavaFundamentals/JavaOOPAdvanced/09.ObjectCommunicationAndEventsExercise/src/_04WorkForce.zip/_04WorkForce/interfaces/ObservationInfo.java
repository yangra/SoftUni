package _04WorkForce.interfaces;

public interface ObservationInfo extends Informer,Observer {
}
