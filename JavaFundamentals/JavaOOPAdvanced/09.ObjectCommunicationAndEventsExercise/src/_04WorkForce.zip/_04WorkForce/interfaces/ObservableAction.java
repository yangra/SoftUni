package _04WorkForce.interfaces;

public interface ObservableAction extends Doable,Observable {
}
