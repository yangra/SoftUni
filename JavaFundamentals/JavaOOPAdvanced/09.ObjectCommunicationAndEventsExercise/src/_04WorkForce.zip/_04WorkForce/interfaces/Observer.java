package _04WorkForce.interfaces;

public interface Observer {
    void notifyObserver( ObservableAction job);
}
