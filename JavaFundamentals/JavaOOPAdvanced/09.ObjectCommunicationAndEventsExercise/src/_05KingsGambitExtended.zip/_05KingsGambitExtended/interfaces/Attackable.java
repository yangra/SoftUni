package _05KingsGambitExtended.interfaces;

public interface Attackable {

    void respondToAttack();
}
