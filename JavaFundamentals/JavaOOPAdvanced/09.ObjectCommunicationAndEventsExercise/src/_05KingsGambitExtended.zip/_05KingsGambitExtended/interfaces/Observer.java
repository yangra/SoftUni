package _05KingsGambitExtended.interfaces;

public interface Observer {

    void update();

    void takeHit();

    int getHealth();
}
