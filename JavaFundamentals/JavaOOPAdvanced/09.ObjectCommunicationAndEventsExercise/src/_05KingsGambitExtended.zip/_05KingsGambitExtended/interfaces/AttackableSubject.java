package _05KingsGambitExtended.interfaces;

public interface AttackableSubject extends Attackable, Subject {
}
