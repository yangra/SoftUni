package _03DependencyInversion;

public interface Strategy {
    long doOperation(int firstOperand, int secondOperand);
}
