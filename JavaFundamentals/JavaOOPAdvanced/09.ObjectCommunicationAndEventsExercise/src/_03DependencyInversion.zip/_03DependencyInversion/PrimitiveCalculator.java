package _03DependencyInversion;


public class PrimitiveCalculator {
//
//    private boolean isAddition;
//    private OperationAdd additionStrategy;
//    private OperationSubtract subtractionStrategy;
//
//    public PrimitiveCalculator(){
//        this.additionStrategy = new OperationAdd();
//        this.subtractionStrategy = new OperationSubtract();
//        this.isAddition = true;
//    }
//
//    public void changeStrategy(char operator){
//        switch (operator){
//            case '+': this.isAddition = true;
//                break;
//            case '-':this.isAddition = false;
//                break;
//        }
//    }
//
//    public int performCalculation(int firstOperand,int secondOperand){
//        if(this.isAddition){
//            return additionStrategy.Calculate(firstOperand,secondOperand);
//        }
//        else{
//            return subtractionStrategy.Calculate(firstOperand,secondOperand);
//        }
//    }
}
