package _02KingsGambit;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        String kingName = reader.readLine();
        String[] royalGuardNames = reader.readLine().split("\\s+");
        String[] footmenNames = reader.readLine().split("\\s+");


        King king = new King(kingName);

        Map<String, RoyalGuard> royalGuards = new HashMap<>();
        Map<String, Footman> footmen = new HashMap<>();
        for (String royalGuardName : royalGuardNames) {
            RoyalGuard royalGuard = new RoyalGuard(royalGuardName);
            king.register(royalGuard);
            royalGuards.put(royalGuardName,royalGuard);
        }

        for (String footmanName : footmenNames) {
            Footman footman = new Footman(footmanName);
            king.register(footman);
            footmen.put(footmanName,footman);
        }

        while (true){
            String[] command = reader.readLine().split("\\s+");
            if("End".equals(command[0])){
                break;
            }

            switch (command[0]){
                case "Kill":
                    String name = command[1];
                    if(royalGuards.containsKey(name)){
                        king.unregister(royalGuards.get(name));
                        royalGuards.remove(name);
                    }
                    if(footmen.containsKey(name)){
                        king.unregister(footmen.get(name));
                        footmen.remove(name);
                    }
                    break;
                case "Attack":
                    king.respondToAttack();
                    break;
                default:
                    throw new IllegalArgumentException("Invalid command!");
            }
        }
    }
}
