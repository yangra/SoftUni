package _02KingsGambit.interfaces;

public interface AttackableSubject extends Attackable, Subject {
}
