package _02KingsGambit.interfaces;

public interface Observer {

    void update();
}
