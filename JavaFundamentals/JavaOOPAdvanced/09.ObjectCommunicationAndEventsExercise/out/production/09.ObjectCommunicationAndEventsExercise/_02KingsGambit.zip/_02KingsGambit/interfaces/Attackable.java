package _02KingsGambit.interfaces;

public interface Attackable {

    void respondToAttack();

}
