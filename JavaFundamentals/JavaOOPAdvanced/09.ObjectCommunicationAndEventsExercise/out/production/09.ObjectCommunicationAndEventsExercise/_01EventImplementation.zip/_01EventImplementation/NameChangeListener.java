package _01EventImplementation;

public interface NameChangeListener {

    void handleChangedName(NameChange event);
}
