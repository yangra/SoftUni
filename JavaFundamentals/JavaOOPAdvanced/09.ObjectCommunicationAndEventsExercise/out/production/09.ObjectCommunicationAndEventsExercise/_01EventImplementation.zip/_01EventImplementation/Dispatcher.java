package _01EventImplementation;

import java.util.ArrayList;
import java.util.List;

public class Dispatcher {
    private String name;
    private List<NameChangeListener> nameChangeListeners;

    public Dispatcher() {
        this.name = "";
        this.nameChangeListeners = new ArrayList<>();
    }

    void addNameChangeListener(NameChangeListener listener){
        this.nameChangeListeners.add(listener);
    }

    void removeNameChangeListener(NameChangeListener listener){
        this.nameChangeListeners.remove(listener);
    }

    void fireNameChangeEvent(NameChange change){
        for (NameChangeListener nameChangeListener : nameChangeListeners) {
            nameChangeListener.handleChangedName(change);
        }
    }
}
