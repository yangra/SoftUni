package _01DefineClassPerson;

public class Person {
    private String name;
    private int age;
}
