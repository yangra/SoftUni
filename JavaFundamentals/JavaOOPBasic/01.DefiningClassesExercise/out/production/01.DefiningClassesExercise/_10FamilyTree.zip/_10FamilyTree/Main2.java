package _10FamilyTree;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;

public class Main2 {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        List<Person> relations = new ArrayList<>();
        
        String query = reader.readLine();
        Person person = new Person();
        setProperty(query,person);
        relations.add(person);

        while (true) {
            String input = reader.readLine();
            if ("End".equals(input)) {
                break;
            }

            if (input.contains("-")) {
                String[] relation = input.split("\\s+-\\s+");

                Person parent = new Person();
                setProperty(relation[0], parent);

                Person child = new Person();
                setProperty(relation[1], child);

                parent.addChild(child);
                child.addParent(parent);
                relations.add(parent);
                relations.add(child);
            } else {
                String[] params = input.split("\\s+");
                String name = params[0] + " " + params[1];
                String date = params[2];

                if (relations.stream().filter(p -> name.equals(p.getName())).count() > 0) {
                    relations.stream()
                            .filter(p -> name.equals(p.getName())).forEach(p -> p.setBirthDate(date));
                }
                if (relations.stream().filter(p -> date.equals(p.getBirthDate())).count() > 0) {
                    relations.stream()
                            .filter(p -> date.equals(p.getBirthDate())).forEach(p -> p.setName(name));
                }
            }
        }

        Set<Integer> forRemove = new HashSet<>();
        for (int i = 0; i < relations.size(); i++) {
            for (int j = i + 1; j < relations.size(); j++) {
                if (relations.get(i).compareTo(relations.get(j)) == 0) {
                    for (int k = 0; k < relations.get(j).getParents().size(); k++) {
                        relations.get(i).addParent(relations.get(j).getParents().get(k));
                    }
                    for (int k = 0; k < relations.get(j).getChildren().size(); k++) {
                        relations.get(i).addChild(relations.get(j).getChildren().get(k));
                    }
                    forRemove.add(j);
                }
            }
        }

        for (int i = forRemove.size()-1; i >= 0; i--) {
            relations.remove((int)forRemove.toArray()[i]);
        }

        Person you = null;
        if (relations.stream().filter(p -> query.equals(p.getName())).count() > 0) {

            you = relations.get(relations.indexOf(relations.stream()
                    .filter(p -> query.equals(p.getName())).findFirst().get()));
        }
        if (relations.stream().filter(p -> query.equals(p.getBirthDate())).count() > 0) {
            you = relations.get(relations.indexOf(relations.stream()
                    .filter(p -> query.equals(p.getBirthDate())).findFirst().get()));
        }

        System.out.println(you);
        System.out.println("Parents:");
        you.getParents().forEach(System.out::println);
        System.out.println("Children:");
        you.getChildren().forEach(System.out::println);
    }

    private static void setProperty(String property, Person person) {
        if (property.contains("/")) {
            person.setBirthDate(property);
        } else {
            String[] names = property.split("\\s+");
            String name = names[0] + " " + names[1];
            person.setName(name);
        }
    }
}
